%Current format:
%Assume animation speed is dynamic and updated with every data point
%Specification of speed can conveniently be used to specify a time slot
%Set time slot size to match default time between feature data points of 2 seconds
%Additional configuration instructions may be inserted which do not take up
%any time, but rather affect subsequent time slots.

% Animator source is available at
% https://github.com/jtsao22/Accelerometer-Animation
% Can change Animator source to use any type of format
% We use the following basic format for convenience, as it conforms well to
% our usage in this class.

%Basic format:
% 2 types of lines
% Expression lines and speed lines
% An expression line consists of the header characters "expr", some
% whitespace, an object (angle) ID number, and a mathematical expression of
% time.
% For coding convenience reasons, we use the letter "a" to represent the
% time dependent component. Note that a is not equal to elapsed time, but
% is related to time.
% Specifically, a is a time varying quantity, whose derivative with respect
% to time is equal to "speed".
% If speed is set to 1, then a will be equal to elapsed time.
% Otherwise, a will be equal to the integral of speed from 0 to elapsed
% time.
% Examples:
% expr 0 (M_PI/180)*(180 + 90*cos(2*M_PI*a)
% This sets angle 0 to oscillate between 90 and 270 degrees at a rate of
% "speed" cycles per second.
% expr 1 fmod(2*M_PI*a,2*M_PI)
% This sets angle 1 to increate at a rate of 1 cycle per second. fmod
% ensures that the resulting value is between 0 and 2*pi. This is typically
% required so that "soft transitions" occur cleanly.
% A speed line is a simple number (double precision floating point).
% When the Animator comes across a speed line, it plays whatever
% expressions it currently has (as well as a soft transition to get there)
% at the given speed for 2 seconds.

%Get the statistics file
[fileName,pathName] = uigetfile('*.stat;*.stat','Select the statistics file');
if(length(fileName) < 2)
    return;
end
load([pathName fileName],'-mat'); %loads {statistics}

%Get and run the motion definition file
[fileName,pathName] = uigetfile('./Motion Definition/*.m;*.m','Select the motion definitions Matlab file');
if(length(fileName) < 2)
    return;
end
eval(sprintf('run ''%s'';',[pathName fileName]));

%Get filename for animator file
[fileName,pathName] = uiputfile('*.anm','Save the Animator file');
if(length(fileName) < 2)
    return;
end

fileID = fopen([pathName fileName],'w');

fwrite(fileID,sprintf('stepsize %f\n',stepSize));

lastClass = -1;
dynamicParms = zeros(numParms,1);
for i = 1:size(statistics,1)
    class = statistics(i,1);
    if ~class
        continue;
    end
    if class ~= lastClass
        %transition
        %if ~class
        %    for j = 1:numObj
        %        fwrite(fileID,sprintf('expr %d 0\n',j-1));
        %    end
        %else
            for j = 1:numObj
                fwrite(fileID,sprintf('expr %d %s\n',j-1,exprMatrix{class,j}));
            end
        %end
    end
    %Dynamic calculations
    for j = 1:numParms
        dynamicParms(j) = dynamicFuncs{j}(statistics(i,:));
    end
    output = sprintf('%s\n',sprintf('%f ',dynamicParms(:)));
    fwrite(fileID,output);
    lastClass = class;
end
fclose(fileID);
clear;