function [ list ] = list_statistics()
list = {...
   ...%Pattern is "<Name>, <Default Value>, <Min>, <Max>,..."
  'Peak_Sidelobe',0,0,2,...
};
range = 1:4:length(list);
list = struct('name',list(range),'default',list(1+range),'min',list(2+range),'max',list(3+range));
end

