%clear;
global samplingFreq winSize increment statList dataCols classification ...
    defaults showPlots
%Computation Variables-----------------------------------------------------
samplingFreq = 320; %in Hz
dataCols = []; %Specify which columns of data should be calculated
               %if empty array, then use default 2:end (all except time)
if exist('handles','var')
    if handles.paraExist
        winSize = handles.para.winsiz;
        increment = handles.para.increment;
    else
        winSize = 16; %Window size in seconds
        increment = 1; %Increment in seconds
    end
    classificationType = handles.test + 1;
    showPlots = handles.plots;
else
    winSize = 16; %Window size in seconds
    increment = 1; %Increment in seconds
    classificationType = 1; %1 = label, 2 = test
    showPlots = 1; %Show plots
end

%--------------------------------------------------------------------------
%Get statistic lists
statList = listStatistics();
defaults = [statList(:).default];
%Get the merged/labeled file
[fileName,pathName] = uigetfile('*.mat;*.MAT;*.lbl;*.LBL','Select the merged MAT-file or the label lbl-file');
if(length(fileName) < 2)
    return;
end
if strcmpi(fileName(end-3:end), '.mat')
    baseName = regexprep(fileName,'\.mat','');
    hasLabel = 0;
    
    load([pathName fileName],'-mat'); %loads {data,header} from merged file
elseif strcmpi(fileName(end-3:end),'.lbl')
    baseName = regexprep(fileName,'\.lbl','');
    hasLabel = 1;
    classificationType = 1;
    
    %Interpret label file
    if exist('read_pam_lbl_data','file')
        [mdata,lblHeader] = read_pam_lbl_data([pathName fileName]);
        load(lblHeader.MATFile,'-mat'); %loads {data,header} from merged file
        
        %Reorder lbl data
        boundaries = cell2mat(cellfun(@(x) getfield(x,'region'),mdata,'UniformOutput',0)); %#ok<GFLD>
        progression = struct('class',cell(1,length(boundaries)/2),'interval',zeros(1,2));
        [values indices] = sort(boundaries);
        iter = 1;
        while iter <= length(indices)
            class = mdata{ceil(indices(iter)/2)}.class;
            if ceil(indices(iter)/2) ~= ceil(indices(iter+1)/2)
                error('Corrupted label file');
            else
                progression(ceil(iter/2)).class = class;
                progression(ceil(iter/2)).interval = [values(iter) values(iter+1)];
                iter = iter+2;
            end
        end
        
    else
        error('Cannot find read_pam_lbl_data: Ensure that the toolboxes folder is part of your MATLAB path');
    end
end

%Get the export file
[fileName,pathName] = uigetfile('*.mat;*.MAT','Select the export MAT-file');
if(length(fileName) < 2)
    return;
end
load([pathName fileName]); %loads {classification,correctClassification,name_list} from export file
switch classificationType
    case 1
        classData = correctClassification;
    case 2
        classData = classification; 
end

if hasLabel
    for iter = 1:length(progression)
        class = progression(iter).class;
        found = 0;
        while ~found
            for iter2 = 1:length(name_list)
                for iter3 = 1:length(name_list{iter2})
                    if strcmp(class,name_list{iter2}{iter3})
                        found = 1;
                        progression(iter).class = iter2;
                        break;
                    end
                end
                if found
                    break;
                end
            end
        end
        if ~found
            error('Incompatible label and export files');
        end
    end
end

dataSize = size(data);
sensorNames = cellfun(@(x) getfield(x,'sensorName'),header,'UniformOutput',0); %#ok<GFLD>
time = data(:,1);

if isempty(dataCols)
   dataCols = 2:size(data,2); 
end

%Setup for loop
winCenter = time(1)+increment/2;
timeMax = max(time);

if ceil((timeMax-winCenter)/increment) ~= length(classData)
    %Check that merged data will line up with export data
    error(['Merged - Export length mismatch:\n',...
        'Merged Window Number: %d\n',...
        'Export Window Number: %d\n'],ceil((timeMax-winCenter)/increment),length(classification));
end
indexMax = length(classData);
statValues = zeros(indexMax,length(statList));
windowIndex = 1;

%Loop
if hasLabel
    %Loop (labels)
    progIndex = 0;
    class = 0;
    if progIndex < length(progression) && winCenter >= progression(progIndex+1).interval(1)
    	progIndex = progIndex + 1;
        class = progression(progIndex).class;
    elseif class ~= 0 && winCenter > progression(progIndex).interval(2)
        class = 0;
    end
    while(windowIndex < indexMax)
        if class ~= 0
            time_bool = and(time>=max(winCenter-winSize/2,progression(progIndex).interval(1)),time<=min(winCenter+winSize/2,progression(progIndex).interval(2)));
            start_index = find(time_bool,1,'first');
            end_index = find(time_bool,1,'last');
            statValues(windowIndex,:) = computeStatistics(data(start_index:end_index,dataCols),windowIndex);
        else
            statValues(windowIndex,:) = defaults;
        end
        
        %Loop increment
        winCenter = winCenter + increment;
        windowIndex = windowIndex + 1;
        if progIndex < length(progression) && winCenter >= progression(progIndex+1).interval(1)
            progIndex = progIndex + 1;
            class = progression(progIndex).class;
        elseif class ~= 0 && winCenter > progression(progIndex).interval(2)
            class = 0;
        end
    end
else
    %Loop (no labels)
    while(windowIndex < indexMax)
        class = classData(windowIndex);
        if class == 0 %0 means unknown
            statValues(windowIndex,:) = defaults;
        else
            leftBound = time(1)+increment*find(classData(1:windowIndex)~= class,1,'last');
            rightBound = time(1)+increment*(1+windowIndex+find(classData(windowIndex:end) ~= class,1,'first'));
            time_bool = and(time>=max(winCenter-winSize/2,leftBound),time<=min(winCenter+winSize/2,rightBound));
            start_index = find(time_bool,1,'first');
            end_index = find(time_bool,1,'last');
            statValues(windowIndex,:) = computeStatistics(data(start_index:end_index,dataCols),windowIndex);
        end

        %Loop increment
        winCenter = winCenter + increment;
        windowIndex = windowIndex + 1;
    end
end
if showPlots
    figure;
    plot(increment*(0:indexMax-1),statValues(:,1));
    legend('Frequency');
    ylabel('Hz');
    xlabel('seconds');
    figure;
    stairs(increment*(0:indexMax-1),classification,'Color','red');
    hold on;
    stairs(increment*(0:indexMax-1),correctClassification,'Color','green');
    legend('Test','Label');
    ylabel('Classification Number');
    xlabel('seconds');
end

statistics = [classData statValues]; 
[fileName,pathName] = uiputfile('*.stat;*.STAT','Save the statistics file');
if(length(fileName) < 2)
    return;
end
if (~strcmp(fileName(end-4:end),'.stat'))
    fileName = [fileName '.stat'];
end
save([pathName fileName],'statistics');
clear;