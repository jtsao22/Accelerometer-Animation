 %Copy and Modify this file to produce different types of motions

%Define stepsize
stepSize = 1;

%Set your number of classes (excluding unknown)
numClasses = 8;

%Set the number of Animation Objects (e.g. angles in Animator)
numObj = 6;

%Number of dynamic parameters to forward per window data point
numParms = 1; %Only speed here

%Given a class and statistic data, the animation generator must know
% 1)how to calculate dynamic parameters for each window
% 2)how to define expressions based on classes

% Calculating dynamic parameters:
% There are numParms different dynamic parameters, and each one may be a
% function of all the statistics and the classification
% You must therefore define a cell array of numParms many function handles
% which take in a numeric array of the form:
% [class statistic1 statistic2 ...]
% You may use Matlab anonymous functions are call additional functions to
% do this;

%numParms by 1 cell array of functions handles
dynamicFuncs = {...
    @(info) info(2)...
};

% Define expressions based on classes:
% During transition from one class to another, the expressions representing
% the functions of time that govern different animation objects will
% change.
% When moving into a particular class, you must define the expressions for
% each animation object that should be set in the animator.
% You must define a numClasses by numObj cell array where the element in
% the ith row and jth column represents the expression governing animation
% object j during a time slot with classification i.
% See User's guide for rules on creating expressions.


%numClasses by numObj cell array of strings
exprMatrix = {...
    %Class 1 LR
    'M_PI/2','M_PI/6*cos(2*M_PI*a))','0',...
    'M_PI/8*(1 + cos(2*M_PI*a)/2)','M_PI/2','0';...
    
    %Class 1 HR
    'M_PI/2','M_PI/8*(1 + 3*cos(2*M_PI*a))','0',...
    'M_PI/8*(1 + 3*cos(2*M_PI*a)/2)','M_PI/2','0';...
    
    %Class 2 LR
    'M_PI/18*(9 + 2*cos(2*M_PI*a))','0','5*M_PI/12',...
    'M_PI/12*(1+cos(2*M_PI*a))','0','0';...
    
    %Class 2 HR
    'M_PI/36*(17 + 11*cos(2*M_PI*a))','0','5*M_PI/12',...
    'M_PI/12*(1+cos(2*M_PI*a))','0','0';...
    
    %Class 3 LR
    '0','M_PI/12*(1+cos(2*M_PI*a))','0',...
    'M_PI/36*(17+5*cos(2*M_PI*a))','M_PI','0';...
    
    %Class 3 HR
    '0','M_PI/12*(1+cos(2*M_PI*a))','0',...
    'M_PI/36*(15+13*cos(2*M_PI*a))','M_PI','0';...
    
    %Class 4 LR
    'M_PI/360*(11+5*cos(M_PI*(1+2*a)))','0','M_PI/36*(1+5*cos(2*M_PI*a))',...
    'M_PI/2','0','0';...
    
    %Class 4 HR
    'M_PI/360*(11+5*cos(M_PI*(1+2*a)))','0','M_PI/18*(1+6*cos(2*M_PI*a))',...
    'M_PI/2','0','0'...
};
