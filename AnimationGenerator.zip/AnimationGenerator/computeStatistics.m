function [ statistics ] = compute_statistics( windowData, windowIndex )
    global samplingFreq  statList;
    statistics = zeros(1,length(statList));
    for i = 1:length(statList)
       switch statList(i).name
           case 'Peak_Sidelobe'
               L = length(windowData);
               N = 2^(nextpow2(L));
               
               T = 1; %min period in seconds
               %k/N = f/f_s
               DC_margin = ceil(N/(2*T*samplingFreq));
               ft = fft(windowData,N);
               U = ceil((N+1)/2);
               ft = abs(ft(1:U,:)); %Remove redundancy, take abs
               ft = ft.^2/L^2; % square and scale (power/energy estimation)
               ft = mean(ft,2); %Average all sensors/directions
               
               if rem(N,2)
                   ft(2:end) = ft(2:end)*2;
               else
                   ft(2:end-1) = ft(2:end-1)*2;
               end
               [SL_peak SL_idx] = max(ft(DC_margin:end));
               value = (SL_idx+DC_margin)*samplingFreq/N;
               if value < statList(i).min || value > statList(i).max
                   statistics(1,i) = statList(i).default;
               else
                   statistics(1,i) = value;
               end
       end
    end
end

